#include <stdio.h>
#include <stdlib.h>
#include "../include/utils.h"


/*Inicializa as amostras e os clusters de forma aleatória*/
void initialize_coords(float *sample_vector_x,float *sample_vector_y,float* clusters_vector_x,float* clusters_vector_y,int * clusters_samples,int sample_numbers,int clusters_numbers){
  srand(10);
  //iniciar amostras
  for(int i=0; i<sample_numbers; i++){
    sample_vector_x[i] = (float) rand() / RAND_MAX;
    sample_vector_y[i] = (float) rand() / RAND_MAX;
  }
  //iniciar clusters, sendo que terao as mesmas coordendas que as primeiras amostras
  for(int i=0; i<clusters_numbers;i++){
    clusters_vector_x[i] = sample_vector_x[i];
    clusters_vector_y[i] = sample_vector_y[i];
    clusters_samples[i] = 0;
  }
}


/*Atualiza amostras de um cluster*/
void update_samples_clusters(float *sample_vector_x,float *sample_vector_y,float* clusters_vector_x,float* clusters_vector_y,int * clusters_samples,int sample_numbers,int clusters_numbers){
   float new_cluster_x[4],new_cluster_y[4],sample_x[4],sample_y[4];
   float centroids_vector_x[clusters_numbers];
   float centroids_vector_y[clusters_numbers];
   float distance[4];
   int new_cluster_index[4];
   int remainder = sample_numbers % 4;

   //iniciar vetores de centroides e numero de amostras em cada cluster
   for(int i =0; i< clusters_numbers; i++){
     centroids_vector_x[i] = 0;
     centroids_vector_y[i] = 0;
     clusters_samples[i] = 0;
   }
   int i=0;
   for(; i<sample_numbers-remainder; i+=4){
      new_cluster_x[0] = clusters_vector_x[0];
      new_cluster_x[1] = clusters_vector_x[0];
      new_cluster_x[2] = clusters_vector_x[0];
      new_cluster_x[3] = clusters_vector_x[0];

      new_cluster_y[0] = clusters_vector_y[0];
      new_cluster_y[1] = clusters_vector_y[0];
      new_cluster_y[2] = clusters_vector_y[0];
      new_cluster_y[3] = clusters_vector_y[0];

      new_cluster_index[0] = 0;
      new_cluster_index[1] = 0;
      new_cluster_index[2] = 0;
      new_cluster_index[3] = 0;

      sample_x[0] = sample_vector_x[i];
      sample_x[1] = sample_vector_x[i+1];
      sample_x[2] = sample_vector_x[i+2];
      sample_x[3] = sample_vector_x[i+3];

      sample_y[0] = sample_vector_y[i];
      sample_y[1] = sample_vector_y[i+1];
      sample_y[2] = sample_vector_y[i+2];
      sample_y[3] = sample_vector_y[i+3];

      distance[0] = (clusters_vector_x[0]-sample_x[0])*(clusters_vector_x[0]-sample_x[0])+(clusters_vector_y[0]-sample_y[0])*(clusters_vector_y[0]-sample_y[0]);
      distance[1] = (clusters_vector_x[0]-sample_x[1])*(clusters_vector_x[0]-sample_x[1])+(clusters_vector_y[0]-sample_y[1])*(clusters_vector_y[0]-sample_y[1]);
      distance[2] = (clusters_vector_x[0]-sample_x[2])*(clusters_vector_x[0]-sample_x[2])+(clusters_vector_y[0]-sample_y[2])*(clusters_vector_y[0]-sample_y[2]);
      distance[3] = (clusters_vector_x[0]-sample_x[3])*(clusters_vector_x[0]-sample_x[3])+(clusters_vector_y[0]-sample_y[3])*(clusters_vector_y[0]-sample_y[3]);
    
     //calculo da distancia da amostra a todos os centroides e guardado o centroide mais proximo
     for(int j=1; j<clusters_numbers;j++){
      float new_distance[4];
      new_distance[0] = (clusters_vector_x[j]-sample_x[0])*(clusters_vector_x[j]-sample_x[0])+(clusters_vector_y[j]-sample_y[0])*(clusters_vector_y[j]-sample_y[0]);
      new_distance[1] = (clusters_vector_x[j]-sample_x[1])*(clusters_vector_x[j]-sample_x[1])+(clusters_vector_y[j]-sample_y[1])*(clusters_vector_y[j]-sample_y[1]);
      new_distance[2] = (clusters_vector_x[j]-sample_x[2])*(clusters_vector_x[j]-sample_x[2])+(clusters_vector_y[j]-sample_y[2])*(clusters_vector_y[j]-sample_y[2]);
      new_distance[3] = (clusters_vector_x[j]-sample_x[3])*(clusters_vector_x[j]-sample_x[3])+(clusters_vector_y[j]-sample_y[3])*(clusters_vector_y[j]-sample_y[3]);
      if(new_distance[0]<distance[0]){
        new_cluster_index[0] = j;
        distance[0] = new_distance[0];
      }
      if(new_distance[1]<distance[1]){
        new_cluster_index[1] = j;
        distance[1] = new_distance[1];
      }
      if(new_distance[2]<distance[2]){
        new_cluster_index[2] = j;
        distance[2] = new_distance[2];
      }
      if(new_distance[3]<distance[3]){
        new_cluster_index[3] = j;
        distance[3] = new_distance[3];
      }
     }

   
     //Somar as componentes do x e do y das amostras
     centroids_vector_x[new_cluster_index[0]] += sample_x[0];
     centroids_vector_x[new_cluster_index[1]] += sample_x[1];
     centroids_vector_x[new_cluster_index[2]] += sample_x[2];
     centroids_vector_x[new_cluster_index[3]] += sample_x[3];

     centroids_vector_y[new_cluster_index[0]] += sample_y[0];
     centroids_vector_y[new_cluster_index[1]] += sample_y[1];
     centroids_vector_y[new_cluster_index[2]] += sample_y[2];
     centroids_vector_y[new_cluster_index[3]] += sample_y[3];

     clusters_samples[new_cluster_index[0]]++;
     clusters_samples[new_cluster_index[1]]++;
     clusters_samples[new_cluster_index[2]]++;
     clusters_samples[new_cluster_index[3]]++;
   }

   for(; i<sample_numbers; i++){
      new_cluster_x[0] = clusters_vector_x[0];
      new_cluster_y[0] = clusters_vector_y[0];
      new_cluster_index[0] = 0;

      sample_x[0] = sample_vector_x[i];
      sample_y[0] = sample_vector_y[i];

      distance[0] = (clusters_vector_x[0]-sample_x[0])*(clusters_vector_x[0]-sample_x[0])+(clusters_vector_y[0]-sample_y[0])*(clusters_vector_y[0]-sample_y[0]);

     //calculo da distancia da amostra a todos os centroides e guardado o centroide mais proximo
     for(int j=1; j<clusters_numbers;j++){
      float new_distance;
      new_distance = (clusters_vector_x[j]-sample_x[0])*(clusters_vector_x[j]-sample_x[0])+(clusters_vector_y[j]-sample_y[0])*(clusters_vector_y[j]-sample_y[0]);

      if(new_distance<distance[0]){
          new_cluster_index[0] = j;
          distance[0] = new_distance;
        }
     }

   
     //Somar as componentes do x e do y das amostras
     centroids_vector_x[new_cluster_index[0]] += sample_x[0];
     centroids_vector_y[new_cluster_index[0]] += sample_y[0];
     clusters_samples[new_cluster_index[0]]++;
   }

   //calcular cada centroide e atualizar cluster
   for(int i = 0; i < clusters_numbers; i++){
     clusters_vector_x[i] = centroids_vector_x[i] / clusters_samples[i];
     clusters_vector_y[i] = centroids_vector_y[i] / clusters_samples[i];
   }

}


/*Verificar se houve alteações à posição dos clusters*/
int has_converged(float *old_clusters_x,float *old_clusters_y,float *new_clusters_x,float *new_clusters_y,int clusters_numbers){
  for(int i = 0; i < clusters_numbers ; i++){
    if(new_clusters_x[i] != old_clusters_x[i] || new_clusters_y[i] != old_clusters_y[i])
      return 0;
  }
  return 1;
}
