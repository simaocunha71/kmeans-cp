#include <stdio.h>
#include <stdlib.h>
#include "../include/utils.h"



#define N 10000000
#define K 4


int main(){

float * sample_vector_x = (float *) malloc(sizeof(float)*N);//vetor das coordenadas das amostras
float * sample_vector_y = (float *) malloc(sizeof(float)*N);//vetor das coordenadas das amostras
float * clusters_vector_x = (float *) malloc(sizeof(float)*K); //vetor das coordenadas dos clusters
float * clusters_vector_y = (float *) malloc(sizeof(float)*K); //vetor das coordenadas dos clusters
int * clusters_samples = (int *) malloc(sizeof(int)*K); // vetor de numero de amostras por cluster
float * old_clusters_x = (float *) malloc(sizeof(float)*K);
float * old_clusters_y = (float *) malloc(sizeof(float)*K);

for(int i = 0; i < K; i++){
      old_clusters_x[i] = 0;
      old_clusters_y[i] = 0;
    }
int iterations = 0;

printf("Initializing\n");
initialize_coords(sample_vector_x,sample_vector_y,clusters_vector_x,clusters_vector_y,clusters_samples,N,K);
update_samples_clusters(sample_vector_x,sample_vector_y,clusters_vector_x,clusters_vector_y,clusters_samples,N,K);
printf("Processing...\n");

while(!has_converged(old_clusters_x,old_clusters_y,clusters_vector_x,clusters_vector_y,K)){

    for(int i = 0; i < K; i++){
      old_clusters_x[i] = clusters_vector_x[i];
      old_clusters_y[i] = clusters_vector_y[i];
    }

    update_samples_clusters(sample_vector_x,sample_vector_y,clusters_vector_x,clusters_vector_y,clusters_samples,N,K);

    iterations++;


}

printf("N = %d, K = %d\n",N,K);
for(int i = 0; i <K; i++){
printf("Center: (%0.3f, %0.3f) : Size: %d\n",clusters_vector_x[i],clusters_vector_y[i],clusters_samples[i]);
}
printf("Iterations : %d\n",iterations);

free(sample_vector_x);
free(sample_vector_y);
free(clusters_vector_x);
free(clusters_vector_y);
free(clusters_samples);
free(old_clusters_x);
free(old_clusters_y);

  return 0;
}
