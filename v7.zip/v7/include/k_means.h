#include "utils.h"

/**
 * @brief Implementation of k-means algorithm
 */
void k_means();