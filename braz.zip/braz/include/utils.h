#ifndef ___utils_h___
#define ___utils_h___

void initialize_coords(float *sample_vector_x,float *sample_vector_y,float* clusters_vector_x,float* clusters_vector_y,int * clusters_samples,int sample_numbers,int clusters_numbers);

void update_samples_clusters(float *sample_vector_x,float *sample_vector_y,float* clusters_vector_x,float* clusters_vector_y,int * clusters_samples,int sample_numbers,int clusters_numbers);

int has_converged(float *old_clusters_x,float *old_clusters_y,float *new_clusters_x,float *new_clusters_y,int clusters_numbers);

#endif //___k_means_h___

